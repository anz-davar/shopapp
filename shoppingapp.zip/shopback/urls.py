from django.urls import path
from .views import ProductList, CartItemList, CartItemDetail, CartDetail, RegisterApi
# from .views import CustomTokenObtainPairView, CustomTokenRefreshView, RegisterView
from rest_framework_simplejwt import views as jwt_views

urlpatterns = [
    path('products/', ProductList.as_view(), name='product-list'),
    path('cartitems/', CartItemList.as_view(), name='cartitem-list'),
    path('cartitems/<int:pk>/', CartItemDetail.as_view(), name='cartitem-detail'),
    # path('cart/<int:pk>/', CartDetail.as_view(), name='cart-detail'),
    path('cart/', CartDetail.as_view(), name='cart-detail'),
    path('token/', jwt_views.TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('token/refresh/', jwt_views.TokenRefreshView.as_view(), name='token_refresh'),
    path('register', RegisterApi.as_view()),

]
