# serializers.py

from django.contrib.auth.models import User
from rest_framework import serializers

from .models import Product, Cart, CartItem


# serializers.py


# Register serializer
class RegisterSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ('id', 'username', 'password', 'email', 'first_name', 'last_name')
        extra_kwargs = {'password': {'write_only': True}
                        }

    def create(self, validated_data):
        user = User.objects.create_user(validated_data['username'], password=validated_data['password'],
                                        email=validated_data['email'],
                                        first_name=validated_data['first_name'], last_name=validated_data['last_name'])
        return user


# User serializer
class UserSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = '__all__'


class ProductSerializer(serializers.ModelSerializer):
    class Meta:
        model = Product
        fields = '__all__'
        # read_only_fields = ( 'name', 'description', 'image', 'price', 'stock')
        # read_only_fields = ('image',)


class CartItemSerializer(serializers.ModelSerializer):
    product_id = serializers.PrimaryKeyRelatedField(
        queryset=Product.objects.all(),
        source='product',
        write_only=True,
        required=False,
    )

    product = ProductSerializer(required=False, read_only=True)

    class Meta:
        model = CartItem
        fields = '__all__'

    # def create(self, validated_data):
    #     print(validated_data)
    #     product_data = validated_data.pop('product', None)
    #     product_id_from_product = product_data.get('id') if product_data else None
    #
    #     if product_id_from_product:
    #         # If 'product' was provided as an ID, use it to set the product_id
    #         validated_data['product_id'] = product_id_from_product
    #
    #     return super().create(validated_data)


class CartSerializer(serializers.ModelSerializer):
    items = CartItemSerializer(many=True, read_only=True)

    class Meta:
        model = Cart
        fields = '__all__'
