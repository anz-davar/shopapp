import React from 'react';
import {Link} from 'react-router-dom';
import Alert from 'react-bootstrap/Alert';
import {Row} from "react-bootstrap";
import {Product} from "./Product";


function ProductsList({token, cartItems, setCartItems, products, cartId}) {
    console.log(token)
    console.log('token here is')
    return (
        <>
            {token == null || token === "" ?
                (<Alert variant='warning'>
                        You are not logged in. Please <Link to={"/login"}>login</Link> to see your products. </Alert>
                ) : (<Row md={2} xs={1} lg={3} className='g-3'>

                    {products.map((product) => {
                        return (<Product key={product.id} product={product} cartItems={cartItems}
                                         setCartItems={setCartItems} token={token} cartId={cartId}/>
                        )
                    }
                        )}
                        </Row>)}
                </>);
            }

export default ProductsList;
