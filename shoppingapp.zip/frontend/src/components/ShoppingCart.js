import {Offcanvas, Stack} from "react-bootstrap";
import {formatCurrency} from "../utilities/formatCurrency";
import {CartItem} from "./CartItem";
import ProductDataService from "../services/product-services";
import Button from "react-bootstrap/Button";


export function ShoppingCart({isOpen, closeCart, cartItems, setCartItems, token}) {
    async function removeFromCart(id) {
        const existingProductIndex = cartItems.findIndex(item => item.product.id === id)
        await ProductDataService.deleteCartItem(cartItems[existingProductIndex].id, token)
        setCartItems(prevCartItems => prevCartItems.filter(item => item.product.id !== id))
    }

    async function payCart() {
        await ProductDataService.payCart({"is_paid": true}, token)
    }


    return <>
        <Offcanvas show={isOpen} onHide={closeCart} placement='end'>
            <Offcanvas.Header closeButton>
                <Offcanvas.Title>Cart</Offcanvas.Title>
            </Offcanvas.Header>
            <Offcanvas.Body>
                <Stack gap={3}>
                    {cartItems.map(item => (item.quantity > 0 &&
                        <CartItem key={item.product.id} item={item}
                                  removeFromCart={() => removeFromCart(item.product.id)}/>
                    ))}
                    <div
                        className='ms-auto fw-bold fs-5'>Total {' '} {formatCurrency(cartItems.reduce((total, cartItem) => {
                        return total + (cartItem?.product.price || 0) * cartItem.quantity
                    }, 0))}</div>

                    {cartItems.length > 0 && <Button variant="warning" onClick={payCart}>Pay order</Button>}
                </Stack>
            </Offcanvas.Body>

        </Offcanvas>
    </>
}
