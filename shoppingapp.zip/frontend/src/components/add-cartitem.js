import React from 'react';

function AddCartItem() {
    return (
        <div className="App"> AddCartItem
        </div>);
}

export default AddCartItem;